./ulordrig -o stratum+tcp://ulord.uupool.cn:5560 -u address.worker -p x -t 1
